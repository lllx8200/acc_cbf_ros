#include "qp_acc.h"

int main(int argc, char **argv)
{
    ros::init(argc, argv, "qp_acc_node");
    ros::NodeHandle nh;

    ACC *acc = new ACC();

    for (int k=1; k < total_k; k++)
    {
        std::cout << "次数k:" << k << std::endl;
        acc->clf_cbf_qp();
        
        std::cout <<std::endl;
    }
    
    return 0;
}