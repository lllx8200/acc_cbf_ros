#include "qp_acc.h"
#include "math.h"

std::string x_path  = "/home/wsxlxl/qp_ws/date/x.txt";
std::ofstream x_stream(x_path);

std::string u_path  = "/home/wsxlxl/qp_ws/date/u.txt";
std::ofstream u_stream(u_path);

std::string slack_path  = "/home/wsxlxl/qp_ws/date/slack.txt";
std::ofstream slack_stream(slack_path);

ACC::ACC()
{
    //按照申明顺序，逐一进行初始化
    //初始化初始状态0
    x0  <<  0,20,100;
    t   =   0;
    F   <<  0,0,0;
    G   <<  0,0,0;

    CBF = 0;
    CLF = 0;
    delta_CLF << 0,0,0;
    delta_CBF << 0,0,0;
    LfV = 0; 
    LgV = 0;
    LfB = 0;
    LgB = 0;

    //系统变量
    p = x0(0);
    v = x0(1);
    z = x0(2);
    x << x0(0),x0(1),x0(2);
    d_x << 0,0,0;
    u = 0;
    slack = 0;
    fr = 0;

    //二次规划矩阵与参数
    A.setZero(4,2);
    B.setZero(4,1);
    H.setZero(2,2);
    F_.setZero(2,1);
    QPSolution.setZero(2,1);

    //构建状态方程
    x<<p,v,z;

    defineF();
    defineG();
    
    d_x = F + G * u;

    // std::cout<<"初始化测试:"<<std::endl;
    // std::cout<<"x:"<<x<<std::endl;
    // std::cout<<"F:"<<F<<std::endl;
    // std::cout<<"G:"<<G<<std::endl;
    // std::cout<<"u:"<<u<<std::endl;
    // std::cout<<"dx:"<<d_x<<std::endl;
    //存储初始状态
    // xs.row(0) = x0.transpose();
}

void ACC::defineF()
{
    double fr= get_fr(x(1));
    F(0,0)=x(1);
    F(1,0)=-1*fr/m; 
    F(2,0)=v0-x(1);

    // Eigen::Matrix(double,3,1) F_temp;
    // F_temp << F(0,0),F(1,0),F(2,0);
}

void ACC::defineG()
{
    G(0,0)=0;
    G(1,0)=1/m; 
    G(2,0)=0;
}

double ACC::get_fr(double v)
{
    float f0 = 0.1;
    float f1 = 5;
    float f2 = 0.25;
    return fr = f0+f1*v+pow(v,2)*f2;
}
void ACC::defineCLF()
{
    CLF = pow((x(1)-vd),2);
}
void ACC::defineCBF()
{
    CBF = x(2)-T*x(1)-0.5*pow((x(1)-v0),2)/(cd*g);
}

void ACC::LfV_calculate()
{
    delta_CLF(0,0) = 0; 
    delta_CLF(1,0) = 2*(x(1)-vd);
    delta_CLF(2,0) = 0;
    LfV = delta_CLF.transpose() * F;
}
void ACC::LgV_calculate()
{
    delta_CLF(0,0) = 0; 
    delta_CLF(1,0) = 2*(x(1)-vd);
    delta_CLF(2,0) = 0;
    LgV = delta_CLF.transpose() * G;
}
void ACC::LfB_calculate()
{
    delta_CBF(0,0) = 0; 
    delta_CBF(1,0) = -T-1/(cd*g)*(x(1)-v0);
    delta_CBF(2,0) = 1;
    LfB = delta_CBF.transpose() * F;
}
void ACC::LgB_calculate()
{
    delta_CBF(0,0) = 0; 
    delta_CBF(1,0) = -T-1/(cd*g)*(x(1)-v0);
    delta_CBF(2,0) = 1;
    LgB = delta_CBF.transpose() * G;
}
void ACC::clf_cbf_qp()
{
    defineF();          //得到f
    defineG();          //得到g
    defineCBF();        //得到CBF
    defineCLF();        //得到CLF
    LfV_calculate();    //得到LfV
    LgV_calculate();    //得到LgV
    LfB_calculate();    //得到LfB
    LgB_calculate();    //得到LgB
    get_fr(x(1));
    
    //获得以上参数后，使用二次规划求解器求解
    A(0,0) = LgV;   A(0,1) = -1;
    A(1,0) = -LgB;  A(1,1) = 0;
    A(2,0) = 1;     A(2,1) = 0;
    A(3,0) = -1;    A(3,1) = 0;

    B(0,0) = -LfV - clf_rate * CLF;  
    B(1,0) =  LfB + cbf_rate * CBF;  
    B(2,0) = ca*m*g;     
    B(3,0) = cd*m*g;    

    H(0,0) = weight_input;  H(0,1) = 0;
    H(1,0) = 0;             H(1,1) = weight_slack;

    F_(0,0) = -1*weight_input*fr;
    F_(1,0) = 0;  

    clf_cbf_qp_solver(A,B,H,F_);

    //更新参数
    update();
    date_save();
    test_date_show();
}

void ACC::clf_cbf_qp_solver(Eigen::Matrix<double,4,2> A,Eigen::Matrix<double,4,1> B,Eigen::Matrix<double,2,2> H,Eigen::Matrix<double,2,1> F_)
{
    Eigen::SparseMatrix<double> hessian(2, 2);      //P: n*n正定矩阵,必须为稀疏矩阵SparseMatrix
    Eigen::VectorXd gradient(2);                    //Q: n*1向量
    Eigen::SparseMatrix<double> linearMatrix(4, 2); //A: m*n矩阵,必须为稀疏矩阵SparseMatrix
    Eigen::VectorXd lowerBound(4);                  //L: m*1下限向量
    Eigen::VectorXd upperBound(4);                  //U: m*1上限向量


    hessian.insert(0,0) = H(0,0);hessian.insert(0,1) = H(0,1); 
    hessian.insert(1,0) = H(1,0);hessian.insert(1,1) = H(1,1);
    std::cout << "hessian:" << std::endl
              << hessian << std::endl;
    
    gradient << F_(0,0), F_(1,0);
    std::cout << "gradient:" << std::endl
              << gradient << std::endl;

    linearMatrix.insert(0,0) = A(0,0);linearMatrix.insert(0,1) = A(0,1);
    linearMatrix.insert(1,0) = A(1,0);linearMatrix.insert(1,1) = A(1,1);
    linearMatrix.insert(2,0) = A(2,0);linearMatrix.insert(2,1) = A(2,1);
    linearMatrix.insert(3,0) = A(3,0);linearMatrix.insert(3,1) = A(3,1);
    std::cout << "linearMatrix:" << std::endl
              << linearMatrix << std::endl;
    
    lowerBound << -OsqpEigen::INFTY,-OsqpEigen::INFTY,-OsqpEigen::INFTY,-OsqpEigen::INFTY;
    upperBound << B(0,0), B(1,0),B(2,0),B(3,0);
    std::cout << "upperBound:" << std::endl
              << upperBound << std::endl;

    // instantiate the solver
    OsqpEigen::Solver solver;
 
    // settings
    solver.settings()->setVerbosity(false);
    solver.settings()->setWarmStart(true);
 
    // set the initial data of the QP solver
    solver.data()->setNumberOfVariables(2);   //变量数n
    solver.data()->setNumberOfConstraints(4); //约束数m

    if (!solver.data()->setHessianMatrix(hessian))
        std::cout << "setHessianMatrix(hessian):ERROR" << std::endl;
    if (!solver.data()->setGradient(gradient))
        std::cout << "setGradient(gradient):ERROR" << std::endl;
    if (!solver.data()->setLinearConstraintsMatrix(linearMatrix))
        std::cout << "setLinearConstraintsMatrix(linearMatrix):ERROR" << std::endl;
    if (!solver.data()->setLowerBound(lowerBound))
        std::cout << "setLowerBound(lowerBound):ERROR" << std::endl;
    if (!solver.data()->setUpperBound(upperBound))
        std::cout << "setUpperBound(upperBound):ERROR" << std::endl; 
    // instantiate the solver
    if (!solver.initSolver())
        std::cout << "initSolver():ERROR" << std::endl; 
    // solve the QP problem
    if (!solver.solve())
        std::cout << "solve():ERROR" << std::endl; 
 
    QPSolution = solver.getSolution();
    std::cout << "QPSolution" << std::endl
              << QPSolution << std::endl; //输出为m*1的向量
}

void ACC::update()
{
    d_x = F + G * u;
    x = x + dt * d_x;
    std::cout<< "状态d_x:" << d_x <<std::endl;
    t = t + dt ;
    u = QPSolution(0,0);
    slack = QPSolution(1,0); 
}
void ACC::date_save()
{
    x_stream << x[0] << " " << x[1] << " " << x[2] << std::endl;
    u_stream << u << std::endl;
    slack_stream << slack << std::endl;
}
void ACC::test_date_show()
{
    std::cout<< "当前状态x:" << x <<std::endl;
    std::cout<< "当前输出控制u:" << u <<std::endl;
    std::cout<< "当前输出松弛变量:" << slack <<std::endl;
    std::cout<< "CLF:" << CLF <<std::endl;
    std::cout<< "CBF:" << CBF <<std::endl;
    std::cout<< "LgV:" << LgV <<std::endl;
    std::cout<< "LgB:" << LgB <<std::endl;
    std::cout<< "LfV:" << LfV <<std::endl;
    std::cout<< "LfB:" << LfB <<std::endl;

    //  std::cin.ignore();
}