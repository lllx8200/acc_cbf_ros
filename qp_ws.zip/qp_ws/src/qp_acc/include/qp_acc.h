#ifndef _QP_ACC_
#define _QP_ACC_
//2323_10_17 这是lxl编写的第一个最优化算法，也是第一个完全自己搭建的ros工程
//这是梦开始的地方，怕什么真理无穷，进一寸有进一寸的欢喜

// osqp-eigen
#include <OsqpEigen/OsqpEigen.h>
#include <osqp/osqp.h>
// eigen
// #include <Eigen/Dense>
#include <eigen3/Eigen/Dense>

#include <iostream>
#include <string>
#include <fstream>
#include <ostream>
#include <ros/ros.h>

/*程序结构：
    编写acc模型，结构体方式
*/

//核心参数调整
const double clf_rate = 5;//lemda
const double cbf_rate = 5;//gamma

//参数部分（与模型相关） lxl 2023/10/24  
const double v0 = 14;
const double vd = 24;
const double m = 1650;
const double g = 9.81;
const double ca = 0.3;
const double cd = 0.3;
const double T = 1.8;
const double u_max = ca*m*g;
const double u_min = -1*cd*m*g;
const double weight_input = 2/pow(m,2);
const double weight_slack = 2e-2;

//循环计算参数
const double dt = 0.02;
const double sim_t = 20;
const double total_k = static_cast<int>(std::ceil(sim_t/dt));

//存储空间
static Eigen::MatrixXd xs = Eigen::MatrixXd::Zero(total_k,3);
static Eigen::MatrixXd ts = Eigen::MatrixXd::Zero(total_k,1);
static Eigen::MatrixXd us = Eigen::MatrixXd::Zero(total_k-1,1);
static Eigen::MatrixXd slacks = Eigen::MatrixXd::Zero(total_k-1,1);
static Eigen::MatrixXd hs = Eigen::MatrixXd::Zero(total_k-1,1);
static Eigen::MatrixXd Vs = Eigen::MatrixXd::Zero(total_k-1,1);

class ACC
{
    public:

    ACC();         //初始化系统
    double  get_fr(double v);    
    void    defineF();
    void    defineG();
    void    defineCLF();
    void    defineCBF();
    void    LfV_calculate();
    void    LgV_calculate();
    void    LfB_calculate();
    void    LgB_calculate();
    void    clf_cbf_qp();
    void    clf_cbf_qp_solver(  Eigen::Matrix<double,4,2> A,
                                Eigen::Matrix<double,4,1> B,
                                Eigen::Matrix<double,2,2> H,
                                Eigen::Matrix<double,2,1> F_);
    void    update();
    void    date_save();
    void    test_date_show();
    
    private:

    //系统变量 lxl 2023/10/24
    //初始状态
    Eigen::Matrix<double,3,1> x0;
    double t;

    //系统模型
    Eigen::Matrix<double,3,1> F;
    Eigen::Matrix<double,3,1> G;
    double CBF;
    double CLF;
    Eigen::Matrix<double,3,1> delta_CLF;
    Eigen::Matrix<double,3,1> delta_CBF;

    double LfV;
    double LgV;
    double LfB;
    double LgB;

    //系统变量
    double p;
    double v;
    double z;
    Eigen::Matrix<double,3,1> x;
    Eigen::Matrix<double,3,1> d_x;
    double u;
    double slack;
    double fr;

    //二次规划矩阵与参数
    Eigen::Matrix<double,4,2> A;
    Eigen::Matrix<double,4,1> B;
    Eigen::Matrix<double,2,2> H;
    Eigen::Matrix<double,2,1> F_;
    Eigen::Matrix<double,2,1> QPSolution;

};

#endif