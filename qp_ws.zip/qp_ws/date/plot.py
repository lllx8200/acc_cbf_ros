#!/usr/bin/env python 
#_*_coding:utf-8 _*_
from cProfile import label
from tkinter import Y
from matplotlib import projections
import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm

line_width=0.8
x_lim_start = 0
x_lim_end = 22 

if __name__ == '__main__':
    path = "/home/wsxlxl/qp_ws/date"

    x = np.loadtxt(path+"/x.txt")
    u = np.loadtxt(path+"/u.txt")
    slack = np.loadtxt(path+"/slack.txt")

    t = np.arange(0, x.shape[0] * 0.02, 0.02)

    plt.figure(num=1, figsize=(6, 4))
    plt.plot(t, x[0:, 0], 'r--', label='p:', linewidth=line_width)
    plt.legend(loc=0)
    plt.grid(ls='--')  # 生成网格
    plt.xlim(0, x_lim_end)
    plt.title('p')
    plt.ylabel("Position (m)")
    plt.xlabel("Time (s)")

    plt.figure(num=2, figsize=(6, 4))
    plt.plot(t, x[0:, 1], 'r--', label='V:', linewidth=line_width)
    plt.legend(loc=0)
    plt.grid(ls='--')  # 生成网格
    plt.xlim(0, x_lim_end)
    plt.title('V')
    plt.ylabel("V(m/s)")
    plt.xlabel("Time (s)")

    plt.figure(num=3, figsize=(6, 4))
    plt.plot(t, x[0:, 2], 'g--', label='z:', linewidth=line_width)
    plt.legend(loc=0)
    plt.grid(ls='--')  # 生成网格
    plt.xlim(0, x_lim_end)
    plt.title('Z')
    plt.ylabel("Z (m)")
    plt.xlabel("Time (s)")

    plt.figure(num=4, figsize=(6, 4))
    plt.plot(t, u[0:], 'g--', label='U:', linewidth=line_width)
    plt.legend(loc=0)
    plt.grid(ls='--')  # 生成网格
    plt.xlim(0, x_lim_end)
    plt.title('U')
    plt.ylabel("u (N)")
    plt.xlabel("Time (s)")

    plt.figure(num=5, figsize=(6, 4))
    plt.plot(t, slack[0:], 'g--', label='slack:', linewidth=line_width)
    plt.legend(loc=0)
    plt.grid(ls='--')  # 生成网格
    plt.xlim(0, x_lim_end)
    plt.title('slack')
    plt.ylabel("delta")
    plt.xlabel("Time (s)")

    plt.show()